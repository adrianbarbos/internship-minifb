# internship-minifb
Mini facebook app for internship
